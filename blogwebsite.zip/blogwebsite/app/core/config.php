<?php 

define('ROOT', 'http://localhost/blogWebsite/public');
define('APP_NAME', "My Blog");