<h4>
		Users 
		<a href="<?=ROOT?>/admin/users/add">
			<button class="btn btn-primary">Add New</button>
		</a>
</h4>
<div class="table-responsive">
	<table class="table">	
		<tr>
			<th>#</th>
			<th>Username</th>
			<th>Email</th>
			<th>Role</th>
			<th>Image</th>
			<th>Date</th>
			<th>Action</th>
		</tr>
        <?php
        $query = "select * from users order by id desc"; 
        $rows = query($query);
        ?>
        <?php if (!empty( $rows )) :?> 
           <?php foreach ($rows as $row): ?>       
        <tr>
            <td> <?php echo $row['id'] ?></td>
            <td> <?php echo esc($row['username'] )?></td>
            <td> <?php echo $row['email'] ?></td>
            <td> <?php echo $row['role'] ?></td>
            <td> Image</td>
            <td> <?php echo date("jS, M, Y", strtotime($row['date'])) ?></td>
            <td> 
            <a href="<?=ROOT?>/admin/users/edit/<?=$row['id']?>">
						<button class="btn btn-warning text-white btn-sm"><i class="bi bi-pencil-square"></i></button>
					</a>
					<a href="<?=ROOT?>/admin/users/delete/<?=$row['id']?>">
						<button class="btn btn-danger btn-sm"><i class="bi bi-trash-fill"></i></button>
					</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
</table>
       