<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') { // Check if the form was submitted

    // Retrieve the form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate the form data
    if (empty($username)) {
        $errors[] = 'Username is required';
    }

    
    if (empty($email)) {
        $errors[] = 'Email is required';

    }
    if (!preg_match('/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $$email)) {
        $errors[] = 'Invalid email format';
    }
    
    if (empty($password)) {
        $errors[] = 'Password is required';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters long';
    }
    
    if ($password != $confirm_password) {
        $errors[] = 'Passwords do not match';
    }
 
    // Insert the form data into the database if there are no errors
    if (empty($errors)) {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert the user data into the database
        $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
        $result = mysqli_query($connection, $query);
        
        if ($result) {
            // Redirect the user to the login page
            header('Location: login.php');
            exit;
        } else {
            $errors[] = 'Error inserting data into database';
        }
    }
}
 
?>