<?php 

//Implementing error handling and validation:

// Retrieve user data from database and display in table
$result = mysqli_query($conn, "SELECT * FROM users");

echo "<table>";
echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Actions</th></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo "<td><a href='delete_user.php?id=" . $row['id'] . "'>Delete</a> | <a href='reset_password.php?id=" . $row['id'] . "'>Reset Password</a></td>";
    echo "</tr>";
}

echo "</table>";

//Implementing session management:
// Start session
session_start();

// Set session variable when user logs in
if ($login_successful) {
    $_SESSION['user_id'] = $user_id;
}

// Check session variable on protected pages
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page
    header("Location: login.php");
    exit();
}

// End session when user logs out
session_destroy();


//Implementing error handling and validation:

// Validate email address
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    // Display error message and prevent form submission
    $error_message = "Invalid email address.";
    return;
}

// Validate password length
if (strlen($password) < 8) {
    // Display error message and prevent form submission
    $error_message = "Password must be at least 8 characters.";
    return;
}

// Sanitize user input to prevent SQL injection
$name = mysqli_real_escape_string($conn, $_POST['name']);
$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

?>