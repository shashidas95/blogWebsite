<?php 
//Hash the password:
$password = $_POST['password'];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

//Store the hashed password in the database:
$query = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";
$result = mysqli_query($conn, $query);


//Verify the password:
$query = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    if (password_verify($password, $row['password'])) {
        // Login successful
    } else {
        // Password incorrect
    }
} else {
    // Username not found
}

//Add salt to the password:

$options = [
    'cost' => 12,
    'salt' => mcrypt_create_iv(22, MCRYPT_DEV_URANDOM),
];
$hashed_password = password_hash($password, PASSWORD_DEFAULT, $options);

?>