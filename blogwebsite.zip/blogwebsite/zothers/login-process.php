<?php


// <form method="post" action="login.php">
//   <label>Username:</label>
//   <input type="text" name="username" required><br><br>
  
//   <label>Password:</label>
//   <input type="password" name="password" required><br><br>
  
//   <input type="submit" value="Login">
// </form>
$query = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    if (password_verify($password, $row['password'])) {
        // Login successful
    } else {
        // Password incorrect
    }
} else {
    // Username not found
}
session_start();
$_SESSION['username'] = $username;


?>