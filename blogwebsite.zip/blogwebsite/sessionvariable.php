<?php /* 
Let's say you have a website where users can log in and view their account information. When a user logs in, you want to display their name and email on every page of the website, not just the login page. To do this, you can use the $_SESSION superglobal array to store the user's name and email after they log in.

Here are the steps to implement this:

Create a login form where the user can enter their username and password.
When the user submits the login form, validate their username and password against the database.
If the login is successful, store the user's name and email in the $_SESSION array using $_SESSION['name'] and $_SESSION['email'], respectively. For example:
less
Copy code
// Set session variables
$_SESSION['name'] = $user['name'];
$_SESSION['email'] = $user['email'];
Redirect the user to the main page of the website.
On every page of the website, check if the user is logged in by checking if $_SESSION['name'] and $_SESSION['email'] are set. If they are set, display the user's name and email. For example:
php
Copy code
// Check if user is logged in
if(isset($_SESSION['name']) && isset($_SESSION['email'])) {
  // Display user's name and email
  echo "Welcome, " . $_SESSION['name'] . "! Your email is " . $_SESSION['email'];
} else {
  // Display login link
  echo "Please <a href='login.php'>login</a> to view your account.";
}
By using the $_SESSION superglobal array to store the user's name and email, you can display this information on every page of the website, not just the login page. Additionally, because $_SESSION is a superglobal array, the user's session data can be accessed across different PHP scripts and web pages.


*/?>