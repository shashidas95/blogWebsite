<?php 

define('ROOT', 'http://localhost/blog/public');
define('APP_NAME', "My Blog");