<?php
session_start();

require "../app/core/init.php";
$url = $_GET['url'] ?? 'home'; 
//echo $url;
/* In PHP, the code $_GET['url'] retrieves the value of the "url" parameter from the URL query string. The ?? operator is called the null coalescing operator, which checks if the value of $_GET['url'] is null or not set. If it is null or not set, then the value 'home' is assigned to the variable $url.

In simpler terms, this code assigns the value of the "url" parameter from the URL query string to the $url variable, and if the "url" parameter is not present or has no value, then the $url variable is set to 'home' as a default value. */
$url = strtolower($url);
$url =explode('/', $url);

$page_name = trim($url[0]);
$filename = "../app/pages/".$page_name.".php";
if (file_exists($filename)) {
    require_once $filename;
} else {
    require_once "../app/pages/404.php";
}

/* echo "<pre>";
print_r($filename) */


//echo "homepage";


?>