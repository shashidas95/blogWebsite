   <?php include '../app/pages/includes/header.php'; ?>

   <center>
   <h4>Contact details:</h4>
   Email: email@email.com
   </center>
    <?php include '../app/pages/includes/footer.php'; ?>